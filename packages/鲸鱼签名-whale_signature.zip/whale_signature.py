"""鲸鱼签名：读取/修改机器人自己的 QQ 个性签名（whale-signature 的 Python 移植）。

只对配置里的主人私聊生效；不修改他人签名；每次修改前检查间隔与每日限额。
协议端必须支持 get_stranger_info / set_self_longnick。
"""
from __future__ import annotations

import datetime
import re
import time

from src.plugins import PluginBase, PluginMeta, FieldSchema


class WhaleSignature(PluginBase):
    META = PluginMeta(
        id='whale_signature', name='鲸鱼签名', category='message', enabled_by_default=False,
        description='读取/修改机器人自己的 QQ 个性签名；主人私聊命令，带冷却与每日限额。',
        config_schema={
            'enabled': FieldSchema(type='bool', label='启用签名'),
            'ownerIds': FieldSchema(type='string', label='主人 QQ（逗号分隔）'),
            'dailyLimit': FieldSchema(type='int', label='每天最多修改次数', min=0, max=20),
            'intervalMinutes': FieldSchema(type='int', label='两次修改最小间隔（分钟）', min=0, max=1440),
        },
        default_settings={'enabled': False, 'ownerIds': '', 'dailyLimit': 2, 'intervalMinutes': 720},
    )

    def _owners(self):
        return {x.strip() for x in re.split(r'[,，\s]+', str(self.get('ownerIds', '') or '')) if x.strip()}

    def _state(self):
        data = self.load_state('whale_signature.json', {})
        return data if isinstance(data, dict) else {}

    def _can_change(self):
        state = self._state(); now = time.time()
        day = datetime.date.today().isoformat()
        used = int(state.get('day_count', 0)) if state.get('day') == day else 0
        last = float(state.get('last', 0) or 0)
        limit = max(0, int(self.get('dailyLimit', 2)))
        interval = max(0, int(self.get('intervalMinutes', 720))) * 60
        if used >= limit:
            return False, f'今天已修改 {used}/{limit} 次。'
        remain = interval - (now - last)
        if remain > 0:
            return False, f'距上次修改还需等待 {int(remain // 60) + 1} 分钟。'
        return True, ''

    def _save_change(self):
        state = self._state(); day = datetime.date.today().isoformat()
        state['day'] = day
        state['day_count'] = (int(state.get('day_count', 0)) + 1) if state.get('day') == day else 1
        state['last'] = time.time()
        self.save_state('whale_signature.json', state)

    async def _call(self, runtime, message, action, params):
        transport = runtime._transport_for(message)
        if not transport or not getattr(transport, 'online', False):
            raise RuntimeError('QQ 未连接')
        return await transport.call(action, params, 20)

    async def on_prepare(self, message, runtime):
        if not self.enabled or str(message.get('kind')) != 'private':
            return
        if str(message.get('sender_id') or '') not in self._owners():
            return
        text = str(message.get('text') or '').strip()
        match = re.match(r'^签名\s*(查看|读取|设置|修改)\s*(.*)$', text)
        if not match:
            return
        action, value = match.group(1), match.group(2).strip()
        message['_direct_reply'] = '签名操作已提交。'
        try:
            if action in ('查看', '读取'):
                own = (getattr(runtime, 'self_id', 0)
                       or getattr(getattr(runtime, 'onebot', None), 'self_id', 0)
                       or getattr(getattr(runtime, 'bridge', None), 'self_id', 0))
                data = await self._call(runtime, message, 'get_stranger_info',
                                        {'user_id': int(own or 0)})
                data = data.get('data', data) if isinstance(data, dict) else {}
                sig = data.get('long_nick') or data.get('longNick')
                message['_direct_reply'] = ('当前签名：' + str(sig)) if isinstance(sig, str) else '协议端没有返回签名字段。'
                return
            if not value or len(value) > 80 or '\n' in value or '\r' in value:
                message['_direct_reply'] = '签名须为非空单行、80 字以内。'
                return
            ok, reason = self._can_change()
            if not ok:
                message['_direct_reply'] = reason
                return
            await self._call(runtime, message, 'set_self_longnick', {'longNick': value})
            self._save_change()
            message['_direct_reply'] = '签名修改请求已发送；请稍后读取确认，不要连续重试。'
        except Exception as exc:
            message['_direct_reply'] = '签名操作失败：' + type(exc).__name__
