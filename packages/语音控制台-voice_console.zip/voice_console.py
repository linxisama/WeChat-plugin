"""语音控制台 2.0.0：调用鲸鱼娘本地语音组件朗读，不发送 QQ 语音。

与旧版 voice_console（需要 QQBridge 音频网关）不同，本版只依赖
WhaleVoice 独立组件（127.0.0.1:8765），适合当前 WhaleGirlQQ 5.2.x。
"""
from __future__ import annotations

import asyncio
import json
import re
import urllib.error
import urllib.parse
import urllib.request

from src.plugins import PluginBase, PluginMeta, FieldSchema

HELP = ('语音控制台 2.6.0：语音 状态 / 语音 检测 / 语音 朗读 <文字> / 语音 唱歌 <歌词> / 语音 试听 <文字>。'
        '先安装并启动 WhaleVoice 组件；官方QQ模式只本机朗读。')


def parse_command(text):
    raw = str(text or '').strip()
    if raw == '语音':
        return '帮助', ''
    match = re.fullmatch(r'语音\s+(\S+)(?:\s+([\s\S]*))?', raw)
    return (match[1], (match[2] or '').strip()) if match else None


def _loopback_endpoint(value):
    parsed = urllib.parse.urlsplit(str(value or '').strip())
    if parsed.scheme != 'http' or parsed.hostname not in ('127.0.0.1', 'localhost'):
        return ''
    if parsed.port not in (None, 8765) and not (1024 <= int(parsed.port) <= 65535):
        return ''
    return parsed._replace(path='', query='', fragment='').geturl().rstrip('/')


class VoiceConsole(PluginBase):
    META = PluginMeta(
        id='voice_console', name='语音控制台', category='voice',
        enabled_by_default=False,
        description='调用本机 WhaleVoice 组件朗读文字；主人私聊/授权群聊可用。'
                    '不自动安装组件、不调用云端、不发送 QQ 语音。',
        config_schema={
            'enabled': FieldSchema(type='bool', label='启用插件', group='使用范围'),
            'ownerIds': FieldSchema(type='string', label='允许使用的主人QQ号', group='使用范围',
                                    description='多个用逗号分隔；空值不允许任何人操作。'),
            'allowGroups': FieldSchema(type='bool', label='允许主人在群里朗读', group='使用范围'),
            'readReplies': FieldSchema(type='bool', label='主人聊天回复同时本机朗读', group='使用范围',
                                       description='默认关闭；打开后普通回复会在文字发送成功后尝试补充 QQ 语音。'),
            'sendVoice': FieldSchema(type='bool', label='允许发送 QQ 语音条', group='QQ 语音',
                                      description='仅普通 QQ / QQBridge；官方 QQ 模式不发送。WAV 由协议端转换。'),
            'singRate': FieldSchema(type='int', label='念唱语速（%）', min=-20, max=30),
            'singPitch': FieldSchema(type='int', label='念唱音调（%）', min=-30, max=50),
            'gptEnabled': FieldSchema(type='bool', label='使用 GPT-SoVITS 自然音色'),
            'gptForSpeech': FieldSchema(type='bool', label='朗读也使用 GPT 音色', description='默认只用 GPT 唱歌；开启后普通朗读也走 GPT，CPU 较慢。'),
            'gptEndpoint': FieldSchema(type='string', label='GPT-SoVITS API', description='默认 http://127.0.0.1:9880'),
            'gptRefAudio': FieldSchema(type='string', label='参考音频路径', file_picker=True, file_extensions='.wav'),
            'gptPromptText': FieldSchema(type='string', label='参考音频文字'),
            'gptSpeed': FieldSchema(type='float', label='GPT 语速', min=0.5, max=1.5),
            'songLibrary': FieldSchema(type='string', label='点歌本', multiline=True,
                                       description='每行：歌名|歌词。用户发“点歌 歌名”时自动取歌词；不在本里则把输入当歌词。'),
            'endpoint': FieldSchema(type='string', label='本地语音组件地址', group='语音组件',
                                    description='只接受 127.0.0.1/localhost；默认 8765。'),
            'voice': FieldSchema(type='string', label='系统音色名（可留空）', group='语音组件'),
            'rate': FieldSchema(type='int', label='语速 -10～10', min=-10, max=10, group='语音组件'),
            'volume': FieldSchema(type='int', label='音量 0～100', min=0, max=100, group='语音组件'),
            'maxChars': FieldSchema(type='int', label='单次朗读上限', min=1, max=2000, group='语音组件'),
        },
        default_settings={'enabled': False, 'ownerIds': '', 'allowGroups': False,
                          'readReplies': False, 'sendVoice': True, 'singRate': 8, 'singPitch': 35, 'gptEnabled': False, 'gptForSpeech': False, 'gptEndpoint': 'http://127.0.0.1:9880', 'gptRefAudio': '', 'gptPromptText': '', 'gptSpeed': 0.95, 'songLibrary': '后来|后来 我总算学会了如何去爱，可惜你早已远去 消失在人海\n晴天|故事的小黄花 从出生那年就飘着', 'endpoint': 'http://127.0.0.1:8765',
                          'voice': '', 'rate': 0, 'volume': 100, 'maxChars': 1000},
    )

    def _owners(self):
        return {part for part in re.split(r'[,，\s]+', str(self.get('ownerIds', ''))) if part.isdigit()}

    def _authorized(self, message, private=False):
        if not self.enabled or any(message.get(key) for key in
                                   ('quote', 'quoted', 'reply', 'reference', 'forward', 'forwarded')):
            return False
        who, target = str(message.get('sender_id') or ''), str(message.get('target') or '')
        if who not in self._owners() or not target.isdigit():
            return False
        kind = message.get('kind')
        return (kind == 'private' and target == who) or (
            not private and kind == 'group' and bool(self.get('allowGroups', False)))

    def _base(self):
        base = _loopback_endpoint(self.get('endpoint', 'http://127.0.0.1:8765'))
        if not base:
            raise ValueError('语音组件地址必须是 http://127.0.0.1:端口 或 localhost。')
        return base

    def _call(self, path, payload=None, timeout=5):
        url = self._base() + path
        data = None if payload is None else json.dumps(payload, ensure_ascii=False).encode('utf-8')
        request = urllib.request.Request(url, data=data,
                                         headers={'Content-Type': 'application/json'})
        try:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                body = json.loads(response.read().decode('utf-8'))
        except (urllib.error.URLError, OSError, ValueError) as exc:
            raise ValueError('本地语音组件未启动或不可达；请先安装/启动 WhaleVoice。') from exc
        if not isinstance(body, dict) or not body.get('ok'):
            raise ValueError(str((body or {}).get('error') or '语音组件返回失败'))
        return body

    async def _synthesize(self, text, pitch=0, rate=None):
        text = str(text or '').strip()
        limit = int(self.get('maxChars', 1000))
        if not 1 <= len(text) <= limit:
            raise ValueError(f'朗读文本须为 1～{limit} 字，不会自动截断。')
        payload = {'text': text, 'voice': str(self.get('voice', '')),
                   'rate': int(self.get('rate', 0) if rate is None else rate),
                   'volume': int(self.get('volume', 100)), 'pitch': int(pitch or 0)}
        return await asyncio.to_thread(self._call, '/synthesize', payload, 90)

    def _gpt_sing(self, text):
        import json as _json
        import tempfile, urllib.request, uuid
        import pathlib
        endpoint = str(self.get('gptEndpoint', 'http://127.0.0.1:9880') or '').rstrip('/')
        ref = str(self.get('gptRefAudio', '') or '')
        prompt = str(self.get('gptPromptText', '') or '')
        if not endpoint or not ref:
            raise ValueError('GPT-SoVITS 端点或参考音频未配置')
        payload = {'text': text, 'text_lang': 'zh', 'ref_audio_path': ref,
                   'prompt_text': prompt, 'prompt_lang': 'zh',
                   'text_split_method': 'cut5', 'batch_size': 1, 'media_type': 'wav',
                   'streaming_mode': False,
                   'speed_factor': max(0.5, min(1.5, float(self.get('gptSpeed', 0.95))))}
        request = urllib.request.Request(endpoint + '/tts', data=_json.dumps(payload, ensure_ascii=False).encode('utf-8'),
                                         headers={'Content-Type': 'application/json'}, method='POST')
        output = pathlib.Path(tempfile.gettempdir()) / 'WhaleVoice-out' / (uuid.uuid4().hex + '-gpt.wav')
        output.parent.mkdir(parents=True, exist_ok=True)
        with urllib.request.urlopen(request, timeout=300) as response:
            data = response.read()
        if len(data) < 1000 or data[:4] != b'RIFF':
            raise ValueError('GPT-SoVITS 没有返回有效 WAV')
        output.write_bytes(data)
        return {'path': str(output), 'bytes': len(data), 'mime': 'audio/wav', 'chars': len(text)}

    def _song_text(self, value):
        text = str(value or '').strip()
        for line in str(self.get('songLibrary', '') or '').splitlines():
            title, sep, lyrics = line.partition('|')
            if sep and title.strip() == text and lyrics.strip():
                return lyrics.strip()
        return text

    async def _sing(self, text):
        text = str(text or '').strip()
        limit = int(self.get('maxChars', 1000))
        if not 1 <= len(text) <= limit:
            raise ValueError(f'歌词须为 1～{limit} 字。')
        payload = {'text': text, 'voice': str(self.get('voice', '')),
                   'rate': int(self.get('singRate', 8)), 'pitch': int(self.get('singPitch', 25))}
        return await asyncio.to_thread(self._call, '/sing', payload, 120)

    async def _speak(self, text):
        text = str(text or '').strip()
        limit = int(self.get('maxChars', 1000))
        if not 1 <= len(text) <= limit:
            raise ValueError(f'朗读文本须为 1～{limit} 字，不会自动截断。')
        payload = {'text': text, 'voice': str(self.get('voice', '')),
                   'rate': int(self.get('rate', 0)), 'volume': int(self.get('volume', 100))}
        return await asyncio.to_thread(self._call, '/speak', payload, 70)

    async def on_prepare(self, message, runtime):
        command = parse_command(message.get('text'))
        if not self.enabled or command is None:
            return
        message['_voice_console_command'] = True
        action, value = command
        if action in ('帮助', 'help'):
            message['_direct_reply'] = HELP
            return
        if not self._authorized(message):
            message['_direct_reply'] = '仅接受配置中的主人私聊；群聊需单独允许，引用/转发不执行。'
            return
        try:
            if action == '状态':
                body = await asyncio.to_thread(self._call, '/health', None, 3)
                message['_direct_reply'] = ('本地语音组件在线：' + str(body.get('service') or 'whale-voice')
                                            + ' ' + str(body.get('version') or '') + '。普通QQ/QQBridge可发送语音条；官方QQ只本机朗读。')
            elif action == '检测':
                await asyncio.to_thread(self._call, '/health', None, 3)
                voices = await asyncio.to_thread(self._call, '/voices', None, 8)
                names = voices.get('voices') or []
                message['_direct_reply'] = '组件在线；音色：' + ('、'.join(names[:8]) if names else '未返回系统音色')
            elif action in ('朗读', '发送'):
                if runtime.mode in ('onebot', 'qqbridge') and self.get('sendVoice', True):
                    if self.get('gptEnabled', False) and self.get('gptForSpeech', False):
                        try:
                            audio = await asyncio.to_thread(self._gpt_sing, value)
                        except Exception:
                            audio = await self._synthesize(value)
                    else:
                        audio = await self._synthesize(value)
                    path = str(audio.get('path') or '')
                    if not path or not Path(path).is_file():
                        raise ValueError('语音组件没有返回可用音频文件')
                    message['_voice_audio_path'] = path
                    message['_direct_reply'] = (f"语音已生成 {audio.get('chars', len(value))} 字，"
                                                '文字回执发送后会尝试发送 QQ 语音条。')
                else:
                    result = await self._speak(value)
                    message['_direct_reply'] = f"已在本地朗读 {result.get('chars', len(value))} 字；当前模式不发送QQ语音。"
            elif action == '试听':
                result = await self._speak(value)
                message['_direct_reply'] = f"已在本地朗读 {result.get('chars', len(value))} 字。"
            elif action in ('唱歌', '唱', '点歌'):
                if runtime.mode not in ('onebot', 'qqbridge') or not self.get('sendVoice', True):
                    raise ValueError('官方 QQ 不支持念唱语音条；请用普通 QQ/QQBridge。')
                if self.get('gptEnabled', False):
                    try:
                        audio = await asyncio.to_thread(self._gpt_sing, value)
                    except Exception:
                        audio = await self._sing(self._song_text(value))
                else:
                    audio = await self._sing(value)
                path = str(audio.get('path') or '')
                if not path or not Path(path).is_file():
                    raise ValueError('语音组件没有返回可用音频文件')
                message['_voice_audio_path'] = path
                message['_direct_reply'] = ('念唱已生成；文字回执后会尝试发送 QQ 语音条。'
                                            '这是语调念唱，不是真人歌声。')
            else:
                message['_direct_reply'] = HELP
        except Exception as exc:
            message['_direct_reply'] = '语音操作未完成：' + (str(exc)[:180] if isinstance(exc, ValueError)
                                                          else '请检查本机语音组件。')

    async def on_post_reply(self, message, reply, runtime):
        path = str(message.get('_voice_audio_path', '') or '')
        if not path:
            if (not self.enabled or not self.get('readReplies', False)
                    or message.get('_voice_console_command') or not self._authorized(message)):
                return reply
            if self.get('sendVoice', True) and runtime.mode in ('onebot', 'qqbridge'):
                try:
                    audio = await self._synthesize(reply)
                    path = str(audio.get('path') or '')
                    message['_voice_audio_path'] = path
                except Exception as exc:
                    self._note(runtime, '语音生成未完成：' + str(exc)[:160])
        if path:
            runtime.reply_meta = dict(getattr(runtime, 'reply_meta', None) or {},
                                      media=[{'type': 'record', 'data': {'file': path}}])
        return reply

    def on_sent(self, message, reply, runtime):
        path = str(message.pop('_voice_audio_path', '') or '')
        if path:
            try:
                Path(path).unlink(missing_ok=True)
            except OSError:
                pass
