"""语音回复：用户明确要语音时，AI 正常生成文字，再补一条 QQ 语音条。"""
from __future__ import annotations
import asyncio, json, re, tempfile, urllib.request, uuid
from pathlib import Path
from . import PluginBase, PluginMeta, FieldSchema

TRIGGER = re.compile(r'(发个语音|语音回复|用语音说|说句话|语音说|发条语音)')


class VoiceReply(PluginBase):
    META = PluginMeta(
        id='voice_reply', name='语音回复', category='voice', enabled_by_default=False,
        description='当主人明确要求“发个语音”时，把 AI 的文字回复合成 WAV 并附带 QQ 语音条；失败只保留文字。',
        config_schema={
            'enabled': FieldSchema(type='bool', label='启用语音回复'),
            'endpoint': FieldSchema(type='string', label='WhaleVoice 地址', description='默认 http://127.0.0.1:8765'),
            'voice': FieldSchema(type='string', label='音色（留空默认）'),
            'rate': FieldSchema(type='int', label='语速', min=-20, max=30),
            'allowGroups': FieldSchema(type='bool', label='群聊也允许语音回复'),
            'ownerIds': FieldSchema(type='string', label='允许触发的 QQ（逗号分隔；留空不限制）'),
        },
        default_settings={'enabled': False, 'endpoint': 'http://127.0.0.1:8765', 'voice': '',
                          'rate': 0, 'allowGroups': True, 'ownerIds': ''},
    )

    def _allowed(self, message):
        owners = {x.strip() for x in re.split(r'[,，\s]+', str(self.get('ownerIds', '') or '')) if x.strip()}
        if owners and str(message.get('sender_id') or '') not in owners:
            return False
        if message.get('kind') == 'group' and not self.get('allowGroups', True):
            return False
        return True

    def on_prepare(self, message, runtime):
        if not self.enabled or not self._allowed(message) or message.get('notice'):
            return
        if str(message.get('text') or '').strip() and TRIGGER.search(str(message.get('text') or '')):
            message['_voice_reply_request'] = True

    async def on_post_reply(self, message, reply, runtime):
        if not message.pop('_voice_reply_request', False) or not str(reply or '').strip():
            return reply
        if getattr(runtime, 'mode', '') not in ('onebot', 'qqbridge'):
            return reply
        endpoint = str(self.get('endpoint', 'http://127.0.0.1:8765') or '').rstrip('/')
        if not endpoint:
            return reply
        text = str(reply)[:300]
        payload = {'text': text, 'voice': str(self.get('voice', '') or ''),
                   'rate': int(self.get('rate', 0)), 'volume': 100}
        try:
            data = await asyncio.to_thread(self._request, endpoint, payload)
            path = str(data.get('path') or '')
            if not path or not Path(path).is_file():
                return reply
            meta = dict(getattr(runtime, 'reply_meta', None) or {})
            meta['media'] = list(meta.get('media') or []) + [{'type': 'record', 'data': {'file': path}}]
            runtime.reply_meta = meta
            message['_voice_reply_path'] = path
        except Exception:
            pass
        return reply

    @staticmethod
    def _request(endpoint, payload):
        req = urllib.request.Request(endpoint + '/synthesize',
                                     data=json.dumps(payload, ensure_ascii=False).encode('utf-8'),
                                     headers={'Content-Type': 'application/json'}, method='POST')
        with urllib.request.urlopen(req, timeout=90) as response:
            return json.loads(response.read().decode('utf-8'))

    def on_sent(self, message, reply, runtime):
        path = str(message.pop('_voice_reply_path', '') or '')
        if path:
            try: Path(path).unlink(missing_ok=True)
            except OSError: pass
