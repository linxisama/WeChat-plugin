"""B 站账号只读运营看板：粉丝、播放、互动和每日复盘。

安全边界：
- 只读固定 B 站 API，不接受用户 URL；
- Cookie 从本机文件或环境变量读取，不写日志/不返回给模型；
- 不发布、不评论、不私信、不改资料。
"""
from __future__ import annotations

import datetime
import json
import os
import time
from pathlib import Path

import httpx

from . import PluginBase, PluginMeta, FieldSchema

NAV = 'https://api.bilibili.com/x/web-interface/nav'
REL = 'https://api.bilibili.com/x/relation/stat'
UPSTAT = 'https://api.bilibili.com/x/space/upstat'
HEADERS = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                        '(KHTML, like Gecko) Chrome/126.0 Safari/537.36',
           'Referer': 'https://space.bilibili.com/'}


class BilibiliAccount(PluginBase):
    META = PluginMeta(
        id='bilibili_account', name='B站运营看板', category='utility', enabled_by_default=False,
        description='只读查看 B 站粉丝/播放/互动，生成每日中文复盘；不发布、不评论、不私信。',
        config_schema={
            'enabled': FieldSchema(type='bool', label='启用 B 站看板'),
            'cookieFile': FieldSchema(type='string', label='Cookie 文件', file_picker='file',
                                      description='本机文本文件，内容如 SESSDATA=...; bili_jct=...；不会上传公网。'),
            'cookie': FieldSchema(type='string', label='Cookie（可选，不建议）', multiline=False,
                                  description='也可直接填入；更推荐 Cookie 文件。'),
            'ownerIds': FieldSchema(type='string', label='主人 QQ（逗号分隔）'),
            'targetFollowers': FieldSchema(type='int', label='粉丝目标', min=1, max=100000000),
            'monthlyBudget': FieldSchema(type='float', label='每月预算（元）', min=0, max=1000000),
        },
        default_settings={'enabled': False, 'cookieFile': '', 'cookie': '', 'ownerIds': '',
                          'targetFollowers': 1000, 'monthlyBudget': 0},
    )

    def _owners(self):
        import re
        return {x for x in re.split(r'[,，\s]+', str(self.get('ownerIds', '') or '')) if x}

    def _cookie(self):
        path = str(self.get('cookieFile', '') or '').strip()
        if path:
            try:
                text = Path(path).read_text(encoding='utf-8', errors='ignore').strip()
                if text:
                    return text
            except OSError:
                pass
        return str(self.get('cookie', '') or '').strip()

    @staticmethod
    def _response_data(response):
        response.raise_for_status()
        body = response.json()
        if not isinstance(body, dict) or body.get('code') not in (0, None):
            raise RuntimeError(str(body.get('message') or 'B站接口返回错误'))
        return body.get('data') or {}

    async def _fetch(self):
        cookie = self._cookie()
        if not cookie:
            raise ValueError('还没有配置 B 站 Cookie；请在插件设置里填 Cookie 文件')
        async with httpx.AsyncClient(timeout=10, trust_env=False, headers={**HEADERS, 'Cookie': cookie}) as client:
            nav = await client.get(NAV)
            user = self._response_data(nav)
            mid = str(user.get('mid') or '')
            if not mid:
                raise ValueError('Cookie 未登录或已失效')
            follower = (await client.get(REL, params={'vmid': mid}))
            relation = self._response_data(follower)
            upstat = await client.get(UPSTAT, params={'mid': mid})
            archive = self._response_data(upstat).get('archive') or {}
        return {'mid': mid, 'name': str(user.get('uname') or ''),
                'level': int(user.get('level') or 0),
                'followers': int(relation.get('follower') or 0),
                'following': int(relation.get('following') or 0),
                'views': int(archive.get('view') or 0),
                'likes': int(archive.get('like') or 0),
                'fetched': time.time()}

    def _finance(self):
        data = self.load_state('bili_finance.json', {})
        rows = data.get('rows', []) if isinstance(data, dict) else []
        return [x for x in rows if isinstance(x, dict)][-200:]

    def _record_finance(self, kind, amount, note):
        rows = self._finance()
        rows.append({'kind': kind, 'amount': float(amount), 'note': str(note or '')[:80],
                     'at': time.time()})
        self.save_state('bili_finance.json', {'rows': rows})
        return rows

    def _finance_text(self):
        rows = self._finance()
        cost = sum(float(x.get('amount') or 0) for x in rows if x.get('kind') == 'cost')
        income = sum(float(x.get('amount') or 0) for x in rows if x.get('kind') == 'income')
        budget = float(self.get('monthlyBudget', 0) or 0)
        return (f"累计成本：{cost:.2f} 元\n累计收益：{income:.2f} 元\n"
                f"净额：{income - cost:+.2f} 元" + (f"\n本月预算：{budget:.2f} 元" if budget else ''))

    def _report(self, data):
        previous = self.load_state('bili_last.json', {})
        day = datetime.date.today().isoformat()
        delta = int(data['followers']) - int(previous.get('followers', data['followers']))
        target = max(1, int(self.get('targetFollowers', 1000)))
        remain = max(0, target - int(data['followers']))
        text = (f"B站 {data['name']}（UID {data['mid']}）\n"
                f"粉丝：{data['followers']}（较上次 {delta:+d}）\n"
                f"播放：{data['views']}　点赞：{data['likes']}\n"
                f"目标：{target} 粉，还差 {remain}\n"
                f"{self._finance_text()}\n"
                f"数据时间：{datetime.datetime.fromtimestamp(data['fetched']).strftime('%Y-%m-%d %H:%M')}")
        try:
            self.save_state('bili_last.json', {'day': day, **data})
        except Exception:
            pass
        return text

    async def on_prepare(self, message, runtime):
        if not self.enabled or str(message.get('sender_id') or '') not in self._owners():
            return
        text = str(message.get('text') or '').strip()
        if text in ('B站 状态', 'B站 数据', 'B站 复盘', 'b站 状态'):
            message['_direct_reply'] = '正在读取 B 站数据…'
            try:
                data = await self._fetch()
                message['_direct_reply'] = self._report(data)
            except Exception as exc:
                message['_direct_reply'] = 'B站数据读取失败：' + type(exc).__name__
            return
        import re
        match = re.match(r'^B站\s*(成本|收益)\s*([0-9]+(?:\.[0-9]+)?)\s*(.*)$', text)
        if match:
            kind = 'cost' if match.group(1) == '成本' else 'income'
            amount = float(match.group(2))
            self._record_finance(kind, amount, match.group(3).strip())
            message['_direct_reply'] = '已记录。\n' + self._finance_text()
        elif text in ('B站 财务', 'B站 账本'):
            message['_direct_reply'] = self._finance_text()
